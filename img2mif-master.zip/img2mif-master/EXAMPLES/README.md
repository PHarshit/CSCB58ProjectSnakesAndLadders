###Example for img2mif
***
**Example output of the img2mif converter for Altera Quartus FPGA development.**
	
The .mif file was created by using the following settings. 
	
img2mif example_metroid_GB.bmp 8 8192 2 1

Author: Parker Dillmann
Website: [Longhorn Engineer] (www.longhornengineer.com)
***
